import speech_recognition as sr
from faster_whisper import WhisperModel
import pyttsx3
import subprocess
import os
import time
import datetime
import numpy as np
from scipy.io import wavfile
import sys

# --- CONFIGURATION ---
WHISPER_THRESHOLD = 150  
OLLAMA_MODEL = "openchat:7b" 

print("--- SYSTEM STARTUP ---")
print("1. Loading Whisper Model...")
# Loading globally so it's ready for Voice Mode immediately
whisper_model = WhisperModel("base.en", device="cpu", compute_type="int8")
print("2. Models Loaded.")

# --- SHARED FUNCTIONS ---

def get_ai_response(prompt):
    """
    The BRAIN: Shared by both Voice and Text modes.
    Includes Real-Time Date & Time injection.
    """
    try:
        now = datetime.datetime.now()
        current_time = now.strftime("%I:%M %p")
        current_date = now.strftime("%A, %B %d, %Y")
        
        full_prompt = (
            f"System Data: Today is {current_date}. Time is {current_time}. "
            "You are a helpful AI assistant. "
            f"User says: '{prompt}'. "
            "Give a direct, accurate, and concise answer."
        )
        
        result = subprocess.run(
            ["ollama", "run", OLLAMA_MODEL, full_prompt],
            capture_output=True, text=True, encoding="utf-8", timeout=60
        )
        response = result.stdout.strip()
        response = response.replace("<think>", "").replace("</think>", "")
        
        if not response: return "I didn't get a response."
        return response
    except Exception as e:
        return f"Error: {e}"

def speak(text):
    """The MOUTH: Used only in Voice Mode"""
    try:
        engine = pyttsx3.init()
        engine.setProperty('rate', 160)
        engine.setProperty('volume', 1.0)
        engine.say(text)
        engine.runAndWait()
        if engine._inLoop: engine.endLoop()
    except Exception as e:
        print(f"TTS Error: {e}")

def boost_audio_volume(filename):
    """The EAR AID: Used only in Voice Mode for whispers"""
    try:
        rate, data = wavfile.read(filename)
        if len(data.shape) > 1: data = data[:, 0]
        max_val = np.max(np.abs(data))
        if max_val == 0: return False
        
        target = 30000 
        factor = target / max_val
        boosted_data = (data * factor).astype(np.int16)
        wavfile.write(filename, rate, boosted_data)
        return True
    except:
        return False

# --- MODES ---

def start_text_chat():
    print("\n" + "="*30)
    print("      TEXT CHAT MODE")
    print("   (Type 'menu' to go back)")
    print("="*30)
    
    while True:
        try:
            user_input = input("\nYou: ")
            
            if user_input.lower() in ["exit", "quit"]:
                print("Exiting program.")
                sys.exit()
            
            if user_input.lower() == "menu":
                return # Returns to Main Menu
                
            if not user_input.strip():
                continue

            print("AI: ...")
            response = get_ai_response(user_input)
            print(f"AI: {response}")
            
        except KeyboardInterrupt:
            return

def start_voice_mode():
    print("\n" + "="*30)
    print("      VOICE / WHISPER MODE")
    print("   (Say 'Stop' or 'Menu' to exit)")
    print("="*30)
    
    recognizer = sr.Recognizer()
    mic = sr.Microphone()
    recognizer.dynamic_energy_threshold = False
    recognizer.energy_threshold = WHISPER_THRESHOLD
    recognizer.pause_threshold = 0.8 

    speak("Voice mode active. I am listening.")

    while True:
        with mic as source:
            print(f"\nListening (Thr: {WHISPER_THRESHOLD})...")
            try:
                audio = recognizer.listen(source, timeout=None, phrase_time_limit=10)
                
                # Process Audio
                filename = "temp_input.wav"
                with open(filename, "wb") as f: f.write(audio.get_wav_data())
                boost_audio_volume(filename)
                
                # Transcribe
                print("Transcribing...")
                segments, _ = whisper_model.transcribe(filename, beam_size=5, language="en", condition_on_previous_text=False)
                user_text = " ".join([s.text for s in segments]).strip()
                
                if os.path.exists(filename): os.remove(filename)

                # Validation
                if len(user_text) < 2 or "Thank you" in user_text:
                    print("(Noise ignored)")
                    continue

                print(f"You (Whisper): {user_text}")
                
                # Commands
                if "menu" in user_text.lower():
                    speak("Returning to menu.")
                    return # Go back to main menu
                
                if "stop" in user_text.lower() or "exit" in user_text.lower():
                    speak("Goodbye.")
                    sys.exit()

                # Get & Speak Response
                print("AI Thinking...")
                reply = get_ai_response(user_text)
                print(f"AI: {reply}")
                speak(reply)

            except sr.WaitTimeoutError:
                pass
            except Exception as e:
                print(f"Loop Error: {e}")
                time.sleep(1)

# --- MAIN MENU ---

def main():
    while True:
        print("\n" + "*"*40)
        print("   AI ASSISTANT - MAIN MENU")
        print("*"*40)
        print("1. Voice Mode (Whisper Support)")
        print("2. Text Chat Mode")
        print("3. Exit")
        
        choice = input("\nSelect Option (1-3): ").strip()
        
        if choice == "1":
            start_voice_mode()
        elif choice == "2":
            start_text_chat()
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
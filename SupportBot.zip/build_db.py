import chromadb
import json
import os
import sys

# --- CONFIGURATION ---
DATA_FILE = "dataset.json"
DB_FOLDER = "my_vector_db"

def build():
    print("--- BUILDING DATABASE (UNIVERSAL MODE) ---")
    
    # 1. Load Data
    if not os.path.exists(DATA_FILE):
        print(f"❌ Error: {DATA_FILE} not found!")
        return

    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"❌ JSON Error: {e}")
        return

    if len(data) == 0:
        print("❌ Error: JSON file is empty.")
        return

    # 2. Setup DB
    print(f"Loaded {len(data)} records.")
    print("Initializing Database...")
    
    client = chromadb.PersistentClient(path=DB_FOLDER)
    try: client.delete_collection("faq_collection")
    except: pass
    
    collection = client.create_collection(name="faq_collection")

    # 3. Insert Data (The Fix)
    ids = []
    docs = []
    
    print("Inserting data...")

    for i, item in enumerate(data):
        # --- UNIVERSAL LOGIC ---
        # Instead of looking for item['question'], we loop through EVERYTHING.
        # This prevents KeyErrors.
        
        full_text_parts = []
        
        # Loop through every key:value pair in this record
        for key, value in item.items():
            # Clean the text
            clean_key = str(key).strip()
            clean_val = str(value).strip()
            
            # Format it nicely
            full_text_parts.append(f"{clean_key}: {clean_val}")
        
        # Join them into one big block of text
        full_text = "\n".join(full_text_parts)
        
        ids.append(f"id_{i}")
        docs.append(full_text)
        
        # Batch save every 500 items
        if len(ids) >= 500:
            collection.add(ids=ids, documents=docs)
            ids, docs = [], []
            print(f"   Processed {i+1} records...")

    # Save remaining
    if ids:
        collection.add(ids=ids, documents=docs)

    print("\n" + "="*40)
    print("✅ DATABASE BUILT SUCCESSFULLY.")
    print("="*40)

if __name__ == "__main__":
    build()
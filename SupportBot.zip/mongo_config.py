from pymongo import MongoClient
import gridfs
import datetime
import pytz 

# --- CONFIGURATION ---
MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "SupportBot"

# Define Indian Timezone
IST = pytz.timezone('Asia/Kolkata')

class MongoDBHandler:
    def __init__(self):
        try:
            self.client = MongoClient(MONGO_URI)
            self.db = self.client[DB_NAME]
            self.fs = gridfs.GridFS(self.db) 
            self.logs = self.db["logs"]      
            print(f"Connected to MongoDB: {DB_NAME}")
        except Exception as e:
            print(f"MongoDB Connection Error: {e}")

    def save_log(self, interaction_type, text, audio_bytes=None, filename="audio.wav"):
        """
        Saves Text AND Audio to MongoDB with INDIAN TIME.
        """
        file_id = None
        
        # 1. Save Audio to GridFS
        if audio_bytes:
            file_id = self.fs.put(
                audio_bytes, 
                filename=filename,
                metadata={"uploaded_at": datetime.datetime.now(IST)} 
            )

        # 2. Create Log Entry with IST
        log_entry = {
            "timestamp": datetime.datetime.now(IST),
            "type": interaction_type, 
            "text_content": text,
            "audio_file_id": file_id,
            "filename": filename
        }

        # 3. Insert
        self.logs.insert_one(log_entry)
        print(f"   [MongoDB] Saved {interaction_type} at {datetime.datetime.now(IST).strftime('%H:%M:%S')}")

# Initialize
db = MongoDBHandler()
import json
import random
import datetime

def generate_it_dataset():
    print("Generating 20,000 Corporate IT Support Records...")
    
    data = []
    
    # --- IT ASSETS & TOOLS ---
    laptops = ["Dell Latitude 7420", "MacBook Pro M1", "Lenovo ThinkPad X1", "HP EliteBook"]
    software = ["Visual Studio Code", "Microsoft Teams", "Outlook", "Docker Desktop", "Jira", "Slack", "Zoom", "Android Studio"]
    vpn_clients = ["Cisco AnyConnect", "GlobalProtect", "OpenVPN"]
    servers = ["AWS EC2 Production", "Azure SQL DB", "Internal Jenkins Server", "GitLab Runner"]
    
    locations = ["Block A, Floor 3", "Remote (WFH)", "Bangalore Campus", "London Office", "New York HQ"]
    
    # --- GENERATION LOOP ---
    for i in range(1, 20001):
        # Determine the Category of the IT Ticket
        category = random.choice(["Hardware", "Software_Dev", "Network_VPN", "Access_Identity", "HR_Onboarding"])
        
        # Unique Identifiers
        ticket_id = f"INC-{random.randint(100000, 999999)}"
        asset_tag = f"AST-{random.randint(1000, 9999)}"
        emp_id = f"EMP{random.randint(1000, 9999)}"
        
        q = ""
        a = ""

        # --- 1. HARDWARE (Laptops, Monitors) ---
        if category == "Hardware":
            device = random.choice(laptops)
            issue = random.choice(["blue screen error (BSOD)", "battery not charging", "keyboard keys stuck", "screen flickering", "fan making loud noise"])
            
            q = f"My {device} (Asset: {asset_tag}) is having a {issue}."
            
            if "battery" in issue:
                a = f"Ticket {ticket_id} logged. Please run the BIOS diagnostics tool. If the battery health is 'Poor', visit the IT Desk on Floor 2 for a replacement."
            elif "BSOD" in issue:
                a = f"Stop Code logged for {asset_tag}. Please upload the minidump files to the IT portal. A technician will remote in within 2 hours."
            else:
                a = f"We have logged a hardware repair request ({ticket_id}) for your {device}. A loaner laptop is available at the IT Kiosk while yours is being repaired."

        # --- 2. SOFTWARE & DEV TOOLS (Coding, IDEs) ---
        elif category == "Software_Dev":
            app = random.choice(software)
            err_code = f"0x{random.randint(100, 999)}"
            
            q = f"I cannot open {app}. It crashes with Error {err_code}."
            
            if "Docker" in app:
                a = "Please ensure virtualization is enabled in BIOS and you are part of the 'docker-users' group in Active Directory. Restart the Docker daemon."
            elif "Visual Studio" in app:
                a = f"Try clearing the workspace storage at %APPDATA%/Code/User/workspaceStorage. If {app} persists to fail, reinstall version 1.85."
            else:
                a = f"For {app} error {err_code}, please perform a 'Quick Repair' via Control Panel or reinstall the application from the Company Self-Service Portal."

        # --- 3. NETWORK & VPN (Connectivity) ---
        elif category == "Network_VPN":
            vpn = random.choice(vpn_clients)
            loc = random.choice(locations)
            
            q = f"I am working from {loc} and {vpn} keeps disconnecting."
            
            if "Remote" in loc:
                a = f"Since you are remote, ensure your home ISP is stable. Try changing the {vpn} protocol from DTLS to TLS in settings to fix disconnection issues."
            else:
                a = f"We are detecting network maintenance at {loc}. Please connect to the 'Corp-Backup' Wi-Fi SSID until maintenance is complete."

        # --- 4. IDENTITY & ACCESS (Passwords, Permissions) ---
        elif category == "Access_Identity":
            target = random.choice(servers)
            
            q_variations = [
                f"I need write access to {target}.",
                f"My account is locked out. Employee ID {emp_id}.",
                f"MFA push notification not arriving on my phone.",
                f"Reset password for {target}."
            ]
            q = random.choice(q_variations)
            
            if "access" in q:
                a = f"Access requests for {target} require Manager Approval. Please raise a request in the IDM Portal (idm.company.internal)."
            elif "locked" in q:
                a = f"Your account {emp_id} was locked due to 3 failed attempts. It will auto-unlock in 15 minutes. Or call Helpdesk Ext. 4400."
            else:
                a = "Please verify that your Microsoft Authenticator app is updated. You can also use the 6-digit TOTP code instead of Push Notification."

        # --- 5. HR & ONBOARDING ---
        elif category == "HR_Onboarding":
            q = f"New joining {emp_id} needs a laptop and email setup."
            a = f"Onboarding ticket {ticket_id} created for {emp_id}. Laptop provisioning is in progress. Credentials will be sent to the manager's email by EOD."

        # Add to dataset
        data.append({
            "id": f"REC-{i}",
            "question": q,
            "answer": a
        })

    # Save to file
    with open("dataset.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

    print("✅ DONE! Generated 20,000 IT Support Records.")
    print("Example Q: " + data[0]['question'])
    print("Example A: " + data[0]['answer'])

if __name__ == "__main__":
    generate_it_dataset()
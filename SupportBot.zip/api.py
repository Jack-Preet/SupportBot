import fastapi
from fastapi import UploadFile, File, HTTPException, BackgroundTasks, Response, Form
from pydantic import BaseModel
from faster_whisper import WhisperModel
import edge_tts
import shutil
import os
import time
import subprocess
import chromadb
import json
import csv
from mongo_config import db 

app = fastapi.FastAPI(title="SupportBot APIs")

# ==========================================
# --- CONFIGURATION ---
# ==========================================
# Indian Female: "en-IN-NeerjaNeural"
# Indian Male:   "en-IN-PrabhatNeural"
CURRENT_VOICE = "en-IN-NeerjaNeural"

OLLAMA_MODEL = "openchat:7b"
DB_FOLDER = "my_vector_db"

print("\n--- API STARTUP ---")

print("1. Whisper...")
stt_model = WhisperModel("base.en", device="cpu", compute_type="int8")

print("2. Database...")
chroma_client = chromadb.PersistentClient(path=DB_FOLDER)

print("Ready.")

# ==========================================
# HELPERS
# ==========================================
class TTSRequest(BaseModel):
    text: str

def cleanup_file(path: str):
    """Safely deletes a file"""
    try:
        if os.path.exists(path):
            os.remove(path)
    except:
        pass

def retrieve_knowledge(query: str):
    """Searches the Vector DB"""
    try:
        collection = chroma_client.get_collection(name="faq_collection")
        results = collection.query(query_texts=[query], n_results=1)
        if results['documents'] and len(results['documents'][0]) > 0:
            return results['documents'][0][0][:2000] 
        return None
    except: return None

def generate_llm_response(user_text: str):
    """Gets answer from Ollama"""
    context = retrieve_knowledge(user_text)
    
    if context:
        sys_msg = f"You are a Support AI. Answer using the DATA below.\n--- DATA ---\n{context}\n--------------"
    else:
        sys_msg = "You are a helpful AI. Politely say you don't have that information."

    full_prompt = f"{sys_msg}\nUser: '{user_text}'"
    
    try:
        result = subprocess.run(
            ["ollama", "run", OLLAMA_MODEL, full_prompt],
            capture_output=True, text=True, encoding="utf-8", timeout=60
        )
        clean_resp = result.stdout.strip().replace("<think>", "").replace("</think>", "")
        return clean_resp if clean_resp else "I heard you, but I don't know what to say."
    except Exception as e:
        return f"Brain Error: {str(e)}"

# ==========================================
# 1. VOICE CHAT (End-to-End with Download)
# ==========================================
@app.post(
    "/voice_chat/",
    response_class=Response 
)
async def voice_chat_endpoint(
    bg_tasks: BackgroundTasks,      
    file: UploadFile = File(...)
):
    safe_name = file.filename or "voice_input.wav"
    ts = int(time.time())
    input_filename = f"chat_in_{ts}_{safe_name}"
    output_filename = f"chat_out_{ts}.mp3"

    try:
        # 1. Save User Audio
        with open(input_filename, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # 2. Transcribe (STT)
        print("Listening...")
        segments, _ = stt_model.transcribe(input_filename, beam_size=5)
        user_text = " ".join(s.text for s in segments).strip()
        
        # Log User Input
        with open(input_filename, "rb") as f:
            db.save_log("VoiceChat_User", user_text, f.read(), safe_name)
        
        cleanup_file(input_filename)

        if not user_text:
            raise HTTPException(status_code=400, detail="No speech detected")

        # 3. Get AI Answer
        print(f"Thinking: {user_text}")
        ai_text_response = generate_llm_response(user_text)

        # 4. Generate Audio (Edge-TTS)
        print(f"Speaking: {ai_text_response[:30]}...")
        communicate = edge_tts.Communicate(ai_text_response, CURRENT_VOICE)
        await communicate.save(output_filename)

        # 5. Read Audio
        with open(output_filename, "rb") as f:
            audio_data = f.read()

        if not audio_data:
            raise HTTPException(status_code=500, detail="Generated audio was empty")

        # Log AI Output
        db.save_log("VoiceChat_AI", ai_text_response, audio_data, output_filename)

        # Cleanup Output
        cleanup_file(output_filename)

        # 6. Return Response
        return Response(
            content=audio_data, 
            media_type="audio/mpeg", 
            headers={
                "Content-Disposition": f'attachment; filename="{output_filename}"',
                "X-AI-Text": ai_text_response
            }
        )

    except Exception as e:
        cleanup_file(input_filename)
        cleanup_file(output_filename)
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=str(e))

# ==========================================
# 2. STORE VOICE 
# ==========================================
# ==========================================
# 2. STORE VOICE (Forces WAV Format)
# ==========================================
@app.post("/store_voice/")
async def store_voice_file(
    file: UploadFile = File(...),
    speaker_name: str = Form("Unknown")
):
    """
    Uploads an audio file and permanently stores it in MongoDB as .wav
    """
    try:
        print(f"Storing voice for: {speaker_name}")
        
        # 1. Read file into memory
        file_content = await file.read()
        
        # 2. Force .wav extension for the database filename
        original_name = file.filename or "recording"
        # Remove existing extension if present and add .wav
        base_name = os.path.splitext(original_name)[0]
        final_filename = f"{base_name}.wav"
        
        # 3. Save to MongoDB GridFS
        # We access the 'fs' object from your mongo_config directly
        file_id = db.fs.put(
            file_content, 
            filename=final_filename, # <--- Stored as .wav
            content_type="audio/wav", # <--- Metadata says it's WAV
            metadata={
                "speaker": speaker_name, 
                "uploaded_at": time.time(),
                "format": "wav"
            }
        )
        
        # 4. Create a Log Entry so we can find it easily
        db.logs.insert_one({
            "type": "Voice_Upload",
            "speaker": speaker_name,
            "filename": final_filename,
            "audio_file_id": file_id,
            "timestamp": time.time()
        })

        return {
            "status": "success",
            "message": f"Voice stored successfully as {final_filename}",
            "database_id": str(file_id)
        }

    except Exception as e:
        print(f"Storage Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
# ==========================================
# 3. TRAINING (Database)
# ==========================================
def run_training_logic(filepath: str, original_filename: str):
    print(f"[TRAINER] Processing {original_filename}...")
    try:
        data = []
        fname = str(original_filename).lower()

        if fname.endswith(".csv"):
            with open(filepath, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    text_parts = [f"{k}: {v}" for k, v in row.items() if v]
                    data.append("\n".join(text_parts))
                    
        elif fname.endswith(".json"):
            with open(filepath, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
                if isinstance(json_data, list):
                    for item in json_data:
                        text_parts = [f"{k}: {v}" for k, v in item.items() if v]
                        data.append("\n".join(text_parts))

        if not data:
            print("File was empty.")
            return

        try: chroma_client.delete_collection("faq_collection")
        except: pass
        
        collection = chroma_client.create_collection(name="faq_collection")
        
        # Batch Insert
        batch_size = 500
        for i in range(0, len(data), batch_size):
            batch = data[i : i + batch_size]
            ids = [f"id_{j}" for j in range(i, i + len(batch))]
            
            collection.add(ids=ids, documents=batch)
            print(f"   Indexed batch {i} to {i + len(batch)}...")

        print(f"TRAINING COMPLETE.")

    except Exception as e:
        print(f"TRAINING FAILED: {e}")
    finally:
        cleanup_file(filepath)

@app.post("/train/")
async def train_knowledge_base(
    bg_tasks: fastapi.BackgroundTasks, 
    file: UploadFile = File(...)
):
    fname = str(file.filename or "").lower()
    if not (fname.endswith(".json") or fname.endswith(".csv")):
        raise HTTPException(status_code=400, detail="Only .json or .csv files are allowed.")

    temp_filename = f"train_{int(time.time())}_{file.filename}"
    with open(temp_filename, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    safe_name = file.filename or "unknown.file"
    bg_tasks.add_task(run_training_logic, temp_filename, safe_name)
    
    return {"status": "Processing started", "message": "The AI is learning your data in the background."}

# ==========================================
# 4. TRANSCRIBE (STT Only)
# ==========================================
@app.post("/transcribe/")
async def transcribe_audio(file: UploadFile = File(...)):
    safe_name = file.filename or "mic.wav"
    temp_file = f"stt_{int(time.time())}.wav"
    try:
        with open(temp_file, "wb") as f: shutil.copyfileobj(file.file, f)
        segments, _ = stt_model.transcribe(temp_file, beam_size=5)
        text = " ".join(s.text for s in segments).strip()
        cleanup_file(temp_file)
        return {"text": text}
    except Exception as e:
        cleanup_file(temp_file)
        return {"error": str(e)}

# ==========================================
# 5. SPEAK (TTS Only - With Download)
# ==========================================
@app.post("/speak/")
async def speak_only(request: TTSRequest):
    filename = f"tts_{int(time.time())}.mp3"
    try:
        comm = edge_tts.Communicate(request.text, CURRENT_VOICE)
        await comm.save(filename)
        
        with open(filename, "rb") as f: audio_data = f.read()
        cleanup_file(filename)
        
        # FIXED: Added Content-Disposition
        return Response(
            content=audio_data, 
            media_type="audio/mpeg",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        cleanup_file(filename)
        raise HTTPException(500, str(e))